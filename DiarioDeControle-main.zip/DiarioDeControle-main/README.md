# DiarioDeControle
Projeto desenvolvido em Java
Por Willian Beck RIbeiro

Projeto desenvolvido para apresentação para o curso de JavaFX da turma de Sistemas de Informação do 5° período da faculdade UniFAESP.

Desenvolvido em Java, o projeto consiste em Criar, Ler, Deletar e atualizar Diários de controle para formalizar relatórios diários.
O sistema consiste em um login (onde é possível criar vários outro), que dá acesso ao menu de diários, que por este é possível criar, ler e deletar diários que estão salvos no banco de dados SQLite.
O banco de dados é feito para que todas as tabelas tenha uma chave extrangeira do login, pois é pelo login que as informações são separadas de usuário pra usuário.
é possível editar seu perfil também! onde você pode salvar seu nome, sua idade e sua descrição. O perfil é feito automaticamente quando é criado o Login novo!

O projeto é livre para uso!
